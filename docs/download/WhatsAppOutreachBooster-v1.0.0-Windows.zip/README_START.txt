=====================================================
  WhatsApp Outreach Booster Pro (v1.0.0 - Windows)
=====================================================

QUICK START INSTRUCTIONS:
1. Double-click "whatsapp_bot.exe" to launch the application.
2. The WhatsApp background gateway connects automatically.
3. Scan the QR code or use Phone Pairing Code from your WhatsApp app.
4. Import your contacts (.csv / .vcf) or fetch WhatsApp groups.
5. Enter your message and click "Send to All Targets"!

FEATURES:
- Unlimited 1-Click Broadcasts
- 1x - 100x Multi-Round Booster Blast
- Anti-Spam Human Pacing Delays (1.0s - 10.0s)
- Direct Group Contact Extractor
- Isolated Sessions per Account

SUPPORT & LICENSE KEYS:
- WhatsApp Support: +91 9610993628
- Pricing Passes:
  * 1-Day Paid Trial: Rs. 49
  * Monthly Pro Pass: Rs. 299
  * Lifetime VIP Pro: Rs. 999
- Website: https://nk961.github.io/whatsapp_bot/
=====================================================
